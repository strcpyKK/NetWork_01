#!/bin/bash
echo "Content-type: application/json"
echo  ""

cpu=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4}')
mem=$(free | awk '/Mem:/ {printf("%.2f", $3/$2 * 100)}')
disk=$(df / | awk 'NR==2 {gsub("%",""); print $5}')
ip=$(hostname -I | awk '{print $1}')

echo -n "{\"cpu\":\"$cpu\",\"mem\":\"$mem\",\"disk\":\"$disk\",\"ip\":\"$ip\"}"
