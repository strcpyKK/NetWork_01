#!/bin/bash

APP_DIR="$(dirname "$0")"
EXAM_DIR="$APP_DIR/Exam"
WWW_DIR="/var/www/html"
CGI_DIR="/usr/lib/cgi-bin"

# 確保必要目錄存在
sudo mkdir -p "$WWW_DIR"
sudo mkdir -p "$CGI_DIR"
mkdir -p "$HOME/Desktop"

# 1. 將前端三個檔案放到 Apache 網頁根目錄
sudo cp "$APP_DIR/index.html" "$WWW_DIR/index.html"
sudo cp "$APP_DIR/style.css" "$WWW_DIR/style.css"
sudo cp "$APP_DIR/script.js" "$WWW_DIR/script.js"

# 2. 將 test.sh 放到 CGI 目錄並給執行權限
sudo cp "$APP_DIR/test.sh" "$CGI_DIR/test.sh"
sudo chmod 755 "$CGI_DIR/test.sh"

# 3. 將 Exam 資料夾複製到桌面
cp -r "$EXAM_DIR" "$HOME/Desktop/Exam"

# 4. 進入 Exam 並下載 node_modules
cd "$HOME/Desktop/Exam"
npm install

# 5. 執行 try.sh
bash "$HOME/Desktop/Exam/try.sh"
