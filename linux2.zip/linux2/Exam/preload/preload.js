const { contextBridge, ipcRenderer } = require('electron')
contextBridge.exposeInMainWorld('api', {
    toggle: () => ipcRenderer.send('toggle-overlay')
})
