#!/bin/bash

APP_DIR="$(dirname "$0")"

mkdir -p "$APP_DIR/preload"
mkdir -p "$APP_DIR/ui"

cat > "$APP_DIR/preload/preload.js" <<EOF
const { contextBridge, ipcRenderer } = require('electron')
contextBridge.exposeInMainWorld('api', {
    toggle: () => ipcRenderer.send('toggle-overlay')
})
EOF

cat > "$APP_DIR/ui/button.html" <<EOF
<!DOCTYPE html>
<html>
<body style="margin:0;overflow:hidden;">
  <button id="toggle" style="width:40px;height:40px;border:none;background:#0000ff;cursor:pointer;"></button>
  <script>
    const btn = document.getElementById('toggle')
    btn.addEventListener('click', () => {
      if(window.api && window.api.toggle) window.api.toggle()
    })
  </script>
</body>
</html>
EOF

cat > "$APP_DIR/main.js" <<EOF
const { app, BrowserWindow, ipcMain } = require('electron')
const path = require('path')

app.commandLine.appendSwitch('disable-gpu')
app.commandLine.appendSwitch('disable-software-rasterizer')

let overlayWin, btnWin
let overlayVisible = true

function createWindows() {
  const overlayWidth = 450
  const overlayHeight = 380
  const overlayX = 0
  const overlayY = 0

  overlayWin = new BrowserWindow({
    width: overlayWidth,
    height: overlayHeight,
    x: overlayX,
    y: overlayY,
    alwaysOnTop: true,
    frame: false,
    resizable: false,
    skipTaskbar: true,
    webPreferences: { contextIsolation: true, preload: path.join(__dirname,'preload/preload.js') }
  })
  overlayWin.loadURL('http://127.0.0.1/index.html')

  btnWin = new BrowserWindow({
    width: 40,
    height: 40,
    x: overlayX + overlayWidth - 10,
    y: overlayY + 10,
    alwaysOnTop: true,
    frame: false,
    resizable: false,
    transparent: true,
    skipTaskbar: true,
    webPreferences: { contextIsolation: true, preload: path.join(__dirname,'preload/preload.js') }
  })
  btnWin.loadFile(path.join(__dirname,'ui/button.html'))

  ipcMain.on('toggle-overlay', () => {
    if (overlayVisible) {
      overlayWin.hide()
      overlayVisible = false
      btnWin.setBounds({ x: overlayX + 5, y: overlayY + 5, width: 40, height: 40 })
    } else {
      overlayWin.show()
      overlayWin.setAlwaysOnTop(true)
      overlayVisible = true
      const b = overlayWin.getBounds()
      btnWin.setBounds({ x: b.x + b.width - 10, y: b.y + 10, width: 40, height: 40 })
    }
  })
}

app.whenReady().then(createWindows)
EOF

npx electron "$APP_DIR/main.js"
