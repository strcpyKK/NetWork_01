const maxHistory = 50;
let cpuHistory = new Array(maxHistory).fill(0);
let memHistory = new Array(maxHistory).fill(0);
let diskHistory = new Array(maxHistory).fill(0);

let currentView = 'gauges';
let startTime = Date.now();
let currentHue = 180;

const COLOR_CPU = '#00f3ff';
const COLOR_MEM = '#bf00ff';
const COLOR_DISK = '#ffaa00';

function switchView(viewName, event) {
    currentView = viewName;
    document.querySelectorAll('.btn').forEach(btn => btn.classList.remove('active'));
    if(event) event.target.classList.add('active');

    if (viewName === 'gauges') {
        document.getElementById('view-gauges').style.display = 'flex';
        document.getElementById('view-charts').style.display = 'none';
    } else {
        document.getElementById('view-gauges').style.display = 'none';
        document.getElementById('view-charts').style.display = 'block';
        resizeCanvas();
    }
}

function updateVisuals() {
    currentHue = (currentHue + 1) % 360;
    document.documentElement.style.setProperty('--primary-hue', currentHue);

    const now = new Date();
    document.getElementById('real-time').innerText = now.toLocaleTimeString();

    const uptimeSeconds = Math.floor((Date.now() - startTime) / 1000);
    const h = Math.floor(uptimeSeconds / 3600).toString().padStart(2,'0');
    const m = Math.floor((uptimeSeconds % 3600) / 60).toString().padStart(2,'0');
    const s = (uptimeSeconds % 60).toString().padStart(2,'0');
    document.getElementById('uptime').innerText = `${h}:${m}:${s}`;
}

function updateData() {
    fetch('http://127.0.0.1/cgi-bin/test.sh')
        .then(response => response.json())
        .then(data => {
            let cpu = parseFloat(data.cpu) || 0;
            let mem = parseFloat(data.mem) || 0;
            let disk = parseFloat(data.disk) || 0;

            updateGauge('cpu', cpu, COLOR_CPU);
            updateGauge('mem', mem, COLOR_MEM);
            updateGauge('disk', disk, COLOR_DISK);

            cpuHistory.push(cpu); cpuHistory.shift();
            memHistory.push(mem); memHistory.shift();
            diskHistory.push(disk); diskHistory.shift();

            if(currentView === 'charts') drawChart();

            const logMsg = `Synced: CPU ${data.cpu} | RAM ${data.mem} | DISK ${data.disk}`;
            addLog(logMsg);
        })
        .catch(err => addLog('Connection Error: Cannot reach /cgi-bin/test.sh'));
}

function updateGauge(id, value, color) {
    document.getElementById(id + '-val').innerText = value + '%';
    const chart = document.getElementById(id + '-circle');
    chart.style.background = `conic-gradient(${color} ${value}%, #222 0%)`;
    chart.style.boxShadow = `0 0 15px ${color}`;
}

function addLog(msg) {
    const logPanel = document.getElementById('sys-log');
    const time = new Date().toLocaleTimeString('en-GB');
    const div = document.createElement('div');
    div.className = 'log-entry';
    div.innerText = `> [${time}] ${msg}`;
    logPanel.appendChild(div);
    logPanel.scrollTop = logPanel.scrollHeight;
}

function drawChart() {
    const canvas = document.getElementById('historyChart');
    const ctx = canvas.getContext('2d');
    const w = canvas.width; const h = canvas.height;
    ctx.clearRect(0,0,w,h);

    ctx.strokeStyle = 'rgba(255,255,255,0.1)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for(let i=0;i<w;i+=20){ctx.moveTo(i,0);ctx.lineTo(i,h);}
    ctx.stroke();

    drawLine(ctx, cpuHistory, COLOR_CPU, w, h);
    drawLine(ctx, memHistory, COLOR_MEM, w, h);
    drawLine(ctx, diskHistory, COLOR_DISK, w, h);
}

function drawLine(ctx, data, color, w, h) {
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';

    const step = w / (maxHistory - 1);
    data.forEach((val,index)=>{
        const x = index * step;
        const y = h - (val/100*h);
        if(index===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    });
    ctx.stroke();

    ctx.shadowBlur = 5;
    ctx.shadowColor = color;
    ctx.stroke();
    ctx.shadowBlur = 0;
}

function resizeCanvas() {
    const canvas = document.getElementById('historyChart');
    const parent = document.getElementById('view-charts');
    canvas.width = parent.clientWidth;
    canvas.height = parent.clientHeight;
}

window.addEventListener('resize', resizeCanvas);
setInterval(updateVisuals, 100);
setInterval(updateData, 2000);
updateVisuals();
